Geographically Weighted Error Diagnostic Measures for mean signed deviation, mean absolute error, root mean squared error, Pearson's correlation coefficient, and Monte Carlo permutation test for them.

Cite Tsutsumida N., Rodríguez-Veiga P., Harris P., Balzter H., Comber A. Investigating Spatial Error Structures in Continuous Raster Data, accepted, International Journal of Applied Earth Observation and Geoinformation, for this use.
